<script setup>

</script>

<template>
  <main>
    <h1>Autores</h1>
  </main>
</template>
