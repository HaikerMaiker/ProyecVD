<script setup>

</script>

<template>
  <main>
    <h1>Inicio</h1>
  </main>
</template>
